# blender_pip

A Blender addon for managing Python modules inside Blender with PIP. Install either by download .zip or downloading a release. Both should be installable into Blender through the install add-ons interface.

Name in the addon tab: "Development: Python Module Manager"
