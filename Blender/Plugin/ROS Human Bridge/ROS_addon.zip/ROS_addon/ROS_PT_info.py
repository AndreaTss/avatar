import bpy

class ROS_PT_info(bpy.types.Panel):
    bl_idname = "ROS_PT_info"
    bl_label = "Info"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ROS Person"

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="To control a human model through ROS you need to import an MHX2 avatar.")
        col.label(text="Plugin created by Andrea Tessarolo.")
        col.label(text="v1.1")
        row = col.row()

