#import msg types here
from ROS_addon.external.geometry_msgs.msg import Point, Quaternion, Pose
from ROS_addon.external.person_quaternion_msgs.msg import Person_Quaternion, BodyPart_Quaternion
from ROS_addon.external.person_euler_msgs.msg import Person_Euler, BodyPart_Euler

#call call_back functions by msg type here
def object_callback(msg, object=None):
    if object.message_type == 'Point':
        point_callback(msg,object)
    elif object.message_type == 'Quaternion':
        quaternion_callback(msg,object)
    elif object.message_type == 'Pose':
        point_callback(msg.position, object)
        quaternion_callback(msg.orientation, object)
    elif object.message_type == 'Person_Quaternion':
        person_quaternion_callback(msg,object)
    elif object.message_type == 'Person_Euler':
        person_euler_callback(msg,object)

#define msgs call_back functions here
def point_callback(msg, object):
    if object.active_pos_axis[0]:
        object.location[0] = msg.x
    if object.active_pos_axis[1]:
        object.location[1] = msg.y
    if object.active_pos_axis[2]:
        object.location[2] = msg.z

def quaternion_callback(msg, object):
    object.rotation_mode = 'XYZ'
    old_rotation = [None,None,None]
    (old_rotation[0],old_rotation[1],old_rotation[2]) = object.rotation_euler
    object.rotation_mode = 'QUATERNION'
    object.rotation_quaternion.w = msg.w
    object.rotation_quaternion.x = msg.x
    object.rotation_quaternion.y = msg.y
    object.rotation_quaternion.z = msg.z
    object.rotation_mode = 'XYZ'
    for i in (0,1,2):
        if not object.active_rot_axis[i]:
            object.rotation_euler[i] = old_rotation[i]

def person_euler_callback(msg, object):
    print("Attivazione callback Person_Euler")  
    mybones=object.pose.bones
    n=len(msg.bodyParts)
    print("Numero di giunti nel messaggio: ", n, "\n")
    print("______________DEBUGGING______________")

    for i in range(n):
        #save BodyPart's elements in local variables
        currentBone=msg.bodyParts[i].label
        x=msg.bodyParts[i].rotation_x
        y=msg.bodyParts[i].rotation_y
        z=msg.bodyParts[i].rotation_z
        if(currentBone=="Hips"):
            positionX=msg.bodyParts[i].position_x
            positionY=msg.bodyParts[i].position_y
            positionZ=msg.bodyParts[i].position_z
            mybones[currentBone].location = (positionX, positionY, positionZ)

        print("Bone=", currentBone)
        if(currentBone=="Hips"):
            print("position X=", positionX,"\nposition Y=", positionY,"\nposition Z=", positionZ)
        print("rotation X=", x,"\nrotation Y=", y,"\nrotation Z=", z)
        mybones[currentBone].rotation_euler = (x, y, z)
        print("_____________________________________")

def person_quaternion_callback(msg, object):
    print("Attivazione callback Person_Quaternion")
    mybones=object.pose.bones
    n=len(msg.bodyParts)
    print("Numero di giunti nel messaggio: ", n, "\n")
    print("______________DEBUGGING______________")

    for i in range(n):
        #save BodyPart's elements in local variables
        currentBone=msg.bodyParts[i].label
        w=msg.bodyParts[i].rotation_w
        x=msg.bodyParts[i].rotation_x
        y=msg.bodyParts[i].rotation_y
        z=msg.bodyParts[i].rotation_z
        if(currentBone=="Hips"):
            positionX=msg.bodyParts[i].position_x
            positionY=msg.bodyParts[i].position_y
            positionZ=msg.bodyParts[i].position_z
            mybones[currentBone].location = (positionX, positionY, positionZ)

        print("Bone=", currentBone)
        if(currentBone=="Hips"):
            print("position X=", positionX,"\nposition Y=", positionY,"\nposition Z=", positionZ)
        print("rotation W=", w,"\nrotation X=", x,"\nrotation Y=", y,"\nrotation Z=", z)
        mybones[currentBone].rotation_quaternion = (w, x, y, z)
        print("_____________________________________")
